### Flume高可用搭建(Flume-1.8、Kafka-1.1.1)

#### 1、搭建原理图

![1](./img/1.png)

#### 2、服务器介绍

| 服务器名称 | 节点                 |
| ---------- | -------------------- |
| node242    | flume-Agent          |
| node243    | flume-Collector (主) |
| node244    | flume-Collector (从) |



#### 3、搭建流程

##### 1、首先配置flume-Agent（node242服务器）

~~~
省略解压操作，安装包在/home/soft下面
具体命令如下：
cd /home/framework/flume-1.8.0
vi conf/agent.conf

内容：
#agent1 name
agent1.channels = c1
agent1.sources = r1
agent1.sinks = k1 k2
#
##set 设置组，保证后面两台flume在一个组下
agent1.sinkgroups = g1
#
##set 设置管道
agent1.channels.c1.type = memory
agent1.channels.c1.capacity = 1000
agent1.channels.c1.transactionCapacity = 100
#监控文件
agent1.sources.r1.channels = c1
#agent1.sources.r1.type = exec
#监控文件夹
agent1.sources.r1.type = TAILDIR
#元数据保存位置
agent1.sources.r1.positionFile = /home/data/flume_log/taildir_position.json
#agent1.sources.r1.command = tail -F /home/data/log
agent1.sources.r1.filegroups = f1
agent1.sources.r1.filegroups.f1 = /home/data/flume_text/.*log
agent1.sources.r1.fileHeader = true
#
agent1.sources.r1.interceptors = i1 i2
agent1.sources.r1.interceptors.i1.type = static
agent1.sources.r1.interceptors.i1.key = Type
agent1.sources.r1.interceptors.i1.value = LOGIN
agent1.sources.r1.interceptors.i2.type = timestamp
#
## set sink1
agent1.sinks.k1.channel = c1
agent1.sinks.k1.type = avro
agent1.sinks.k1.hostname = node243
agent1.sinks.k1.port = 52020
#
## set sink2
agent1.sinks.k2.channel = c1
agent1.sinks.k2.type = avro
agent1.sinks.k2.hostname = node244
agent1.sinks.k2.port = 52020
#
##set sink group
agent1.sinkgroups.g1.sinks = k1 k2
#
##set failover
agent1.sinkgroups.g1.processor.type = failover
agent1.sinkgroups.g1.processor.priority.k1 = 10
agent1.sinkgroups.g1.processor.priority.k2 = 1
agent1.sinkgroups.g1.processor.maxpenalty = 10000
#

修改flume-env.sh文件
加上JDK
export JAVA_HOME=/usr/java/jdk1.8.0_201-amd64

修改好后，发送到其他服务器上
scp -r /home/framework/flume-1.8.0 node243:/home/frameword/
scp -r /home/framework/flume-1.8.0 node244:/home/frameword/
~~~

##### 2、配置node243和node244

~~~
node243配置如下：
vi collector.conf

#set Agent name
a1.sources = r1
a1.channels = c1
a1.sinks = k1
#
##set channel
a1.channels.c1.type = memory
a1.channels.c1.capacity = 1000
a1.channels.c1.transactionCapacity = 100
#
## other node,nna to nns
a1.sources.r1.type = avro
a1.sources.r1.bind = node243
a1.sources.r1.port = 52020
a1.sources.r1.interceptors = i1
a1.sources.r1.interceptors.i1.type = static
a1.sources.r1.interceptors.i1.key = Collector
a1.sources.r1.interceptors.i1.value = node243
a1.sources.r1.channels = c1
#
##set sink to hdfs
a1.sinks.k1.type=hdfs
a1.sinks.k1.hdfs.path= hdfs://node242:8020/flume/failover/
a1.sinks.k1.hdfs.fileType=DataStream
a1.sinks.k1.hdfs.writeFormat=TEXT
a1.sinks.k1.hdfs.rollInterval=10
a1.sinks.k1.channel=c1
a1.sinks.k1.hdfs.filePrefix=%Y-%m-%d
#


配置node244
vi collector.conf

#set Agent name
a1.sources = r1
a1.channels = c1
a1.sinks = k1
#
##set channel
a1.channels.c1.type = memory
a1.channels.c1.capacity = 1000
a1.channels.c1.transactionCapacity = 100
#
## other node,nna to nns
a1.sources.r1.type = avro
a1.sources.r1.bind = node244
a1.sources.r1.port = 52020
a1.sources.r1.interceptors = i1
a1.sources.r1.interceptors.i1.type = static
a1.sources.r1.interceptors.i1.key = Collector
a1.sources.r1.interceptors.i1.value = node244
a1.sources.r1.channels = c1
#
##set sink to hdfs
a1.sinks.k1.type=hdfs
a1.sinks.k1.hdfs.path= hdfs://node242:8020/flume/failover/
a1.sinks.k1.hdfs.fileType=DataStream
a1.sinks.k1.hdfs.writeFormat=TEXT
a1.sinks.k1.hdfs.rollInterval=10
a1.sinks.k1.channel=c1
a1.sinks.k1.hdfs.filePrefix=%Y-%m-%d
#
~~~

~~~
相关配置参考：https://flume.liyifeng.org/#taildir-source
~~~

##### 3、启动

先启动node244再启动node243然后最后启动node242，先下后上原则！

~~~
node244命令
./bin/flume-ng agent -n a1 -c conf -f conf/collector.conf -Dflume.root.logger=DEBUG,console
node243命令
./bin/flume-ng agent -n a1 -c conf -f conf/collector.conf -Dflume.root.logger=DEBUG,console
node242命令
bin/flume-ng agent -n agent1 -c conf -f conf/agent.conf -Dflume.root.logger=DEBUG,console

参数解释：

-n 指定agent名称，要与配置文件一致（等价于--name)

-c 指定配置文件位置（等价于 --conf）

-f 指定agent配置文件（等价 --conf-file）

-Dflume.root.logger=INFO,console 设置日志等级 
~~~
#### 4、测试

![](./img/2.png)

可以看到里面有几个文件，flume_text是我们flume监控的文件，我们之间往里面生产文件就行了，因为我们监控的是文件夹，而flume_log内是元数据文件，保存的是flume执行的一些元数据。

执行 sh 1.sh

![](./img/3.png)

查看node242:50070

![](./img/4.png)

#### 5、测试高可用

手动kill掉node243这个服务器，我们发现node244服务器进行切换使用，开始收集数据到HDFS

![](./img/5.png)

当我们后续将其node243启动后，我们会发现node244服务器停止工作

![](./img/6.png)

#### 6、Flume Source

##### 	1、AVRO Source

​	Avro Source监听Avro端口接收从外部Avro客户端发送来的数据流。如果与上一层Agent的 [Avro Sink](https://flume.liyifeng.org/#avro-sink) 配合使用就组成了一个分层的拓扑结构。 

![](./img/10.png)

样例：

~~~
#Name the components on this agent
a1.sources = r1
a1.sinks = k1
a1.channels = c1
 
#定制source，绑定channel、主机以及端口
a1.sources.r1.type = avro
a1.sources.r1.channels = c1
a1.sources.r1.bind = 192.168.1.102
a1.sources.r1.port = 4141
 
#Describe the sink
a1.sinks.k1.type = logger
 
#use a channel which buffers events in memory
a1.channels.c1.type = memory
a1.channels.c1.capacity = 1000
a1.channels.c1.transactionCapacity = 100
 
#Bind the source and sink to the channel
a1.sources.r1.channels = c1
a1.sinks.k1.channel = c1
~~~

启动Flume

~~~
flume-ng agent -n a1 -c /usr/flume/conf/ --conf-file /usr/flume/conf/avro.conf -Dflume.root.logger=INFO,consol
~~~

测试

~~~
bin/flume-ng avro-client -c conf -H 192.168.1.102 -p 4141  -F /app/logs/test.log
~~~

##### 2、Thrift Source

​	监听Thrift 端口，从外部的Thrift客户端接收数据流。如果从上一层的Flume Agent的 [Thrift Sink](https://flume.liyifeng.org/#thrift-sink) 串联后就创建了一个多层级的Flume架构（同 [Avro Source](https://flume.liyifeng.org/#avro-source) 一样，只不过是协议不同而已）。Thrift Source可以通过配置让它以安全模式（kerberos authentication）运行。

![](./img/11.png)

​	由于本Source和AVRO很像，例子不做过多讲解，参考下面参数

~~~
a1.sources = r1
a1.channels = c1
a1.sources.r1.type = thrift
a1.sources.r1.channels = c1
a1.sources.r1.bind = 0.0.0.0
a1.sources.r1.port = 4141
~~~

##### 3、Exec Source

​	ExecSource的配置就是设定一个Unix(linux)命令，然后通过这个命令不断输出数据。如果进程退出，Exec Source也一起退出，不会产生进一步的数据。 

![](./img/12.png)

样例参考：

~~~
a1.sources = r1
a1.channels = c1
a1.sources.r1.type = exec
a1.sources.r1.command = tail -F /var/log/secure
a1.sources.r1.channels = c1
参考上述HA搭建的参数设定
~~~

##### 4、Kafka Source

​	Kafka Source就是一个Apache Kafka消费者，它从Kafka的topic中读取消息。 如果运行了多个Kafka Source，则可以把它们配置到同一个消费者组，以便每个source都读取一组唯一的topic分区。 

![](./img/14.png)

参数展示：

~~~
tier1.sources.source1.type = org.apache.flume.source.kafka.KafkaSource
tier1.sources.source1.channels = channel1
tier1.sources.source1.batchSize = 5000
tier1.sources.source1.batchDurationMillis = 2000
tier1.sources.source1.kafka.bootstrap.servers = localhost:9092
tier1.sources.source1.kafka.topics = test1, test2
~~~

样例展示：

首先编写Flume-Agent参数

~~~
#agent1 name
agent1.channels = c1
agent1.sources = r1
agent1.sinks = k1 k2
#
##set 设置组，保证后面两台flume在一个组下
agent1.sinkgroups = g1
#
##set 设置管道
agent1.channels.c1.type = memory
agent1.channels.c1.capacity = 1000
agent1.channels.c1.transactionCapacity = 100
#监控文件
agent1.sources.r1.type = org.apache.flume.source.kafka.KafkaSource
agent1.sources.r1.channels = c1
agent1.sources.r1.batchSize = 5000
agent1.sources.r1.batchDurationMillis = 2000
agent1.sources.r1.kafka.bootstrap.servers = node242:9092,node243:9092,node244:9092
agent1.sources.r1.kafka.topics = shop-topic
# 拦截器
agent1.sources.r1.interceptors = i1 i2
agent1.sources.r1.interceptors.i1.type = static
agent1.sources.r1.interceptors.i1.key = Type
agent1.sources.r1.interceptors.i1.value = LOGIN
agent1.sources.r1.interceptors.i2.type = timestamp

## set sink1
agent1.sinks.k1.channel = c1
agent1.sinks.k1.type = avro
agent1.sinks.k1.hostname = node243
agent1.sinks.k1.port = 52020
#
## set sink2
agent1.sinks.k2.channel = c1
agent1.sinks.k2.type = avro
agent1.sinks.k2.hostname = node244
agent1.sinks.k2.port = 52020
#
##set sink group
agent1.sinkgroups.g1.sinks = k1 k2
#
##set failover
agent1.sinkgroups.g1.processor.type = failover
agent1.sinkgroups.g1.processor.priority.k1 = 10
agent1.sinkgroups.g1.processor.priority.k2 = 1
agent1.sinkgroups.g1.processor.maxpenalty = 10000
#
上述参数需要在HA的Flume执行
~~~

接下来启动Flume和Kafka

~~~
Flume命令：

node244命令
./bin/flume-ng agent -n a1 -c conf -f conf/collector.conf -Dflume.root.logger=DEBUG,console
node243命令
./bin/flume-ng agent -n a1 -c conf -f conf/collector.conf -Dflume.root.logger=DEBUG,console
node242命令
bin/flume-ng agent -n agent1 -c conf -f conf/agent1.conf -Dflume.root.logger=DEBUG,console
~~~

Kafka启动生产者

![](./img/16.png)

查看Flume

![](./img/15.png)

查看HDFS

![](./img/17.png)

#### 7、Flume Sink

##### 1、Kafka Sink

首先创建一个新的Topic

![](./img/7.png)

​	然后修改Flume的主从collector.conf文件

~~~
先将保存HDFS的注释掉
#
##set sink to hdfs
#a1.sinks.k1.type=hdfs
#a1.sinks.k1.hdfs.path= hdfs://node242:8020/flume/failover/
#a1.sinks.k1.hdfs.fileType=DataStream
#a1.sinks.k1.hdfs.writeFormat=TEXT
#a1.sinks.k1.hdfs.rollInterval=10
#a1.sinks.k1.channel=c1
#a1.sinks.k1.hdfs.filePrefix=%Y-%m-%d
#
## 配置sink-Kafka
## Kafka Sink
a1.sinks.k1.channel = c1
# 类型设置Kafka
a1.sinks.k1.type = org.apache.flume.sink.kafka.KafkaSink
# topic名字
a1.sinks.k1.kafka.topic = shop-topic
# ip和端口
a1.sinks.k1.kafka.bootstrap.servers = node242:9092,node243:9092,node244:9092
# 批次大小
a1.sinks.k1.kafka.flumeBatchSize = 20
# 一致性机制
a1.sinks.k1.kafka.producer.acks = 1
# 刷入频率
a1.sinks.k1.kafka.producer.linger.ms = 1
# 数据压缩方式
a1.sinks.k1.kafka.producer.compression.type = snappy
另一台机器同理
~~~

​	然后启动三台服务器

~~~
node244命令
./bin/flume-ng agent -n a1 -c conf -f conf/collector.conf -Dflume.root.logger=DEBUG,console
node243命令
./bin/flume-ng agent -n a1 -c conf -f conf/collector.conf -Dflume.root.logger=DEBUG,console
node242命令
bin/flume-ng agent -n agent1 -c conf -f conf/agent.conf -Dflume.root.logger=DEBUG,console
~~~

​	启动Kafka消费者

~~~
./bin/kafka-console-consumer.sh --bootstrap-server node242:9092 --topic shop-topic
~~~

​	执行操作

![](./img/8.png)

​	查看Kafka消费者

![](./img/9.png)

##### 2、Avro Sink

​	这个Sink可以作为 Flume 分层收集特性的下半部分。发送到此Sink的 Event 将转换为Avro Event发送到指定的主机/端口上。 

![](./img/13.png)

样例参数：

~~~
a1.channels = c1
a1.sinks = k1
a1.sinks.k1.type = avro
a1.sinks.k1.channel = c1
a1.sinks.k1.hostname = 10.10.10.10
a1.sinks.k1.port = 4545
~~~

##### 3、HDFS Sink

​	这个Sink将Event写入Hadoop分布式文件系统（也就是HDFS）。 目前支持创建文本和序列文件。 它支持两种文件类型的压缩。 可以根据写入的时间、文件大小或Event数量定期滚动文件（关闭当前文件并创建新文件）。 它还可以根据Event自带的时间戳或系统时间等属性对数据进行分区。 存储文件的HDFS目录路径可以使用格式转义符，会由HDFS Sink进行动态地替换，以生成用于存储Event的目录或文件名。 使用此Sink需要安装hadoop， 以便Flume可以使用Hadoop的客户端与HDFS集群进行通信。 

样例参考：

~~~
a1.channels = c1
a1.sinks = k1
a1.sinks.k1.type = hdfs
a1.sinks.k1.channel = c1
a1.sinks.k1.hdfs.path = /flume/events/%y-%m-%d/%H%M/%S
a1.sinks.k1.hdfs.filePrefix = events-
a1.sinks.k1.hdfs.round = true
a1.sinks.k1.hdfs.roundValue = 10
a1.sinks.k1.hdfs.roundUnit = minute
整体参考上述HA实现的HDFS文件存储
~~~

#### 8、拦截器

##### 1、时间戳拦截器

​	这个拦截器会向每个Event的header中添加一个时间戳属性进去，key默认是“timestamp ”（也可以通过下面表格中的header来自定义），value就是当前的毫秒值（其实就是用System.currentTimeMillis()方法得到的）。 如果Event已经存在同名的属性，可以选择是否保留原始的值。 

​	时间戳拦截器，将当前时间戳（毫秒）加入到events  header中，key名字为：timestamp，值为当前时间戳。比如在使用HDFS  Sink时候，根据events的时间戳生成结果文件，hdfs.path = hdfs://cdh5/tmp/dap/%Y%m%d

hdfs.filePrefix = log_%Y%m%d_%H

会根据时间戳将数据写入相应的文件中。

但可以用其他方式代替（设置useLocalTimeStamp = true）。

参数介绍

![](./img/18.png)

~~~
官网配置如下：

a1.sources = r1
a1.channels = c1
a1.sources.r1.channels =  c1
a1.sources.r1.type = seq
a1.sources.r1.interceptors = i1
a1.sources.r1.interceptors.i1.type = timestamp
~~~

参考上面HA的例子，里面应用的就是时间戳拦截器

```
在flume的conf目录下新建timestamp.conf文件
```

~~~
#配置文件：timestamp.conf
# Name the components on this agent
a1.sources = r1
a1.sinks = k1
a1.channels = c1
 
# Describe/configure the source
a1.sources.r1.type = syslogtcp
a1.sources.r1.port = 50000
a1.sources.r1.host = node242
a1.sources.r1.channels = c1
 
a1.sources.r1.interceptors = i1
a1.sources.r1.interceptors.i1.preserveExisting= false
a1.sources.r1.interceptors.i1.type = timestamp

# Describe the sink
a1.sinks.k1.type = logger
a1.sinks.k1.channel = c1
 
# Use a channel which buffers events inmemory
a1.channels.c1.type = memory
a1.channels.c1.capacity = 1000
a1.channels.c1.transactionCapacity = 100
~~~

打开一个终端，进入flume的bin目录，输入

`./flume-ng agent -c ../conf -f ../conf/timestamp.conf -Dflume.root.logger=INFO,console -n a1`   

  启动成功后，flume开始监控本主机上的所有IP地址，再开一个终端，向50000端口发TCP数据，命令如下：`echo "TimestampInterceptor" | nc 127.0.0.1 50000`

此时，flume的终端会接收到这个消息，如下：

![](./img/19.png)

##### 2、主机名拦截器

​	这个拦截器会把当前Agent的hostname或者IP地址写入到Event的header中，key默认是“host”（也可以通过配置自定义key），value可以选择使用hostname或者IP地址。 

![](./img/20.png)

官方配置：

~~~
a1.sources = r1
a1.channels = c1
a1.sources.r1.interceptors = i1
a1.sources.r1.interceptors.i1.type = host
~~~

测试案例：

~~~
#配置文件：host.conf
# Name the components on this agent
a1.sources = r1
a1.sinks = k1
a1.channels = c1
 
# Describe/configure the source
a1.sources.r1.type = syslogtcp
a1.sources.r1.port = 50000
a1.sources.r1.host = node242
a1.sources.r1.channels = c1
 
a1.sources.r1.interceptors = i2
a1.sources.r1.interceptors.i2.type = host
a1.sources.r1.interceptors.i2.hostHeader =hostname
a1.sources.r1.interceptors.i2.useIP = false

# Describe the sink
a1.sinks.k1.type = logger
a1.sinks.k1.channel = c1
 
# Use a channel which buffers events inmemory
a1.channels.c1.type = memory
a1.channels.c1.capacity = 1000
a1.channels.c1.transactionCapacity = 100
~~~

进入flume的bin目录，执行

`./flume-ng agent -c ../conf -f ../conf/host.conf -Dflume.root.logger=INFO,console -n a1` 

然后在新的终端输入

`echo "HostInterceptor" | nc 127.0.0.1 50000`    

 结果如下： 

![](./img/21.png)

##### 3、Regex Filtering Interceptor拦截器

​	还有比较重要的Regex Filtering Interceptor，Regex Filtering Interceptor拦截器用于过滤事件，筛选出与配置的正则表达式相匹配的事件。可以用于包含事件和排除事件。常用于数据清洗，通过正则表达式把数据过滤出来

![](./img/22.png)

测试案例：

~~~
#配置文件：regex_filter.conf
# Name the components on this agent
a1.sources = r1
a1.sinks = k1
a1.channels = c1

# Describe/configure the source
a1.sources.r1.type = syslogtcp
a1.sources.r1.port = 50000
a1.sources.r1.host = node242
a1.sources.r1.channels = c1
a1.sources.r1.interceptors = i1
a1.sources.r1.interceptors.i1.type =regex_filter
#全部是数字的数据
a1.sources.r1.interceptors.i1.regex =^[0-9]*$
#排除符合正则表达式的数据
a1.sources.r1.interceptors.i1.excludeEvents =true
# Describe the sink
a1.sinks.k1.type = logger
 
# Use a channel which buffers events inmemory
a1.channels.c1.type = memory
a1.channels.c1.capacity = 1000
a1.channels.c1.transactionCapacity = 100
# Bind the source and sink to the channel
a1.sources.r1.channels = c1
a1.sinks.k1.channel = c1
~~~

这样的配置将会过滤掉所有纯数字的数据。   

  进入bin目录启动flume，执行

`./flume-ng agent -c ../conf -f ../conf/regex_filter.conf -Dflume.root.logger=INFO,console -n a1`     

新开终端输入

`echo "1234" | nc 127.0.0.1 50000`

`echo "1234" | nc 127.0.0.1 50000` 

`echo "1234" | nc 127.0.0.1 50000` 

![](./img/23.png)



#### 9、扩展